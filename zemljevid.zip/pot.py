import csv
import math
import matplotlib.pyplot as plt
import matplotlib.image as mpimg


with open("nodes.csv") as f:
    reader = csv.DictReader(f)
    nodes = {}
    for ln in reader:
        x = float(ln['x'])
        y = float(ln['y'])
        nodes[ln['id']] = {'x': x, 'y': y}

with open("edges.csv") as f:
    reader = csv.DictReader(f)
    edges = list(reader)


seznam_sosednosti = {}

for node in nodes:
    seznam_sosednosti[node] = []

for edge in edges:
    u = edge['u']
    v = edge['v']
    travel_time = edge['travel_time']
    name = edge['name']

    seznam_sosednosti[u].append((v, float(travel_time), name))

    if not edge['oneway']:
        seznam_sosednosti[v].append((u, float(travel_time), name))


# Tu implementiraj dijkstrov algoritem

...

# Tega ne spreminjaj!

zemljevid_fname = "zemljevid.png"
zemljevid_left = 14.41
zemljevid_right = 14.75
zemljevid_up = 46.14
zemljevid_down = 45.98

try:

    img = mpimg.imread(zemljevid_fname)
    implog = plt.imshow(img, extent=(zemljevid_left, zemljevid_right, zemljevid_down, zemljevid_up), aspect='auto')

    plt.plot(
        [nodes[node]['x'] for node in path],
        [nodes[node]['y'] for node in path]
    )

    plt.show()

except NameError:
    print("Če želiš, da se pot nariše, shrani zaporedna vozlišča v spremenljivko `path`")
